package br.com.alura.liter_alura;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LiterAluraApplicationTests {

	@Test
	void contextLoads() {
	}

}
