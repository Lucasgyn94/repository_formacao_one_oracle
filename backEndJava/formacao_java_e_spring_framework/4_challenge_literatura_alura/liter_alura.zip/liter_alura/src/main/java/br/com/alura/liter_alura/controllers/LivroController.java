package br.com.alura.liter_alura.controllers;

import br.com.alura.liter_alura.models.Autor;
import br.com.alura.liter_alura.models.Livro;
import br.com.alura.liter_alura.service.LivroService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.time.LocalDate;
import java.util.List;

@Controller
public class LivroController {

    @Autowired
    private LivroService livroService;

    public void buscarNovoLivro(String buscaDoUsuario) {
        livroService.buscarNovoLivro(buscaDoUsuario);
    }

    public List<Livro> buscarLivrosRegistrados() {
        return livroService.buscarLivrosRegistrados();
    }

    public List<Autor> buscarAutoresRegistrados() {
        return livroService.buscarAutoresRegistrados();
    }

    public List<Autor> buscarAutoresVivosPorAno(LocalDate anoSelecionado) {
        return livroService.buscarAutoresVivosPorAno(anoSelecionado);
    }

    public List<Livro> buscarLivrosPorIdioma(String idiomaSelecionado) {
        return livroService.buscarLivrosPorIdioma(idiomaSelecionado);
    }

    public List<Livro> buscarTop10() {
        return livroService.buscarTop10();
    }

    public List<Autor> buscarAutorPorNome(String pesquisa) {
        return livroService.buscarAutorPorNome(pesquisa);
    }

    public double mediaDeDownloadsPorAutor(String pesquisa) {
        return livroService.mediaDeDownloadsPorAutor(pesquisa);
    }
}
