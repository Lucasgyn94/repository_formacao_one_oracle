package br.com.alura.liter_alura.service;

import br.com.alura.liter_alura.dto.AutorDto;
import br.com.alura.liter_alura.dto.LivroDto;
import br.com.alura.liter_alura.models.Autor;
import br.com.alura.liter_alura.models.Livro;
import br.com.alura.liter_alura.repository.AutorRepository;
import br.com.alura.liter_alura.repository.LivroRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.DoubleSummaryStatistics;
import java.util.List;

@Service
public class LivroService {

    @Autowired
    private ConsumoApi consumoApi;

    @Autowired
    private ConverteDados converteDados;

    @Autowired
    private AutorRepository autorRepository;

    @Autowired
    private LivroRepository livroRepository;

    private final String ADDRESS = "https://gutendex.com/books?search=";

    public void buscarNovoLivro(String buscaDoUsuario) {
        var dados = consumoApi.consumo(ADDRESS + buscaDoUsuario.replace(" ", "%20"));
        salvarNoDb(dados);
    }

    private void salvarNoDb(String dados) {
        try {
            Livro livro = new Livro(converteDados.obterDados(dados, LivroDto.class));
            Autor autor = new Autor(converteDados.obterDados(dados, AutorDto.class));
            Autor autorDb;
            Livro bookDb;

            if (!autorRepository.existsByNome(autor.getNome())) {
                autorRepository.save(autor);
                autorDb = autor;
            } else {
                autorDb = autorRepository.findByNome(autor.getNome());
            }
            if (!livroRepository.existsByNome(livro.getNome())) {
                livro.setAutor(autorDb);
                livroRepository.save(livro);
                bookDb = livro;
            } else {
                bookDb = livroRepository.findByNome(livro.getNome());
            }
            System.out.println(bookDb);
        } catch (NullPointerException e) {
            System.out.println("\n\n*** Livro não encontrado ***\n\n");
        }
    }

    public List<Livro> buscarLivrosRegistrados() {
        return livroRepository.findAll();
    }

    public List<Autor> buscarAutoresRegistrados() {
        return autorRepository.findAll();
    }

    public List<Autor> buscarAutoresVivosPorAno(LocalDate anoSelecionado) {
        return autorRepository.buscarPorAnoDeFalecimento(anoSelecionado);
    }

    public List<Livro> buscarLivrosPorIdioma(String idiomaSelecionado) {
        return livroRepository.buscarPorIdioma(idiomaSelecionado);
    }

    public List<Livro> buscarTop10() {
        return livroRepository.findTop10ByOrderByQuantidadeDeDownloadsDesc();
    }

    public List<Autor> buscarAutorPorNome(String pesquisa) {
        return autorRepository.encontrarPorNome(pesquisa);
    }

    public double mediaDeDownloadsPorAutor(String pesquisa) {
        var livros = livroRepository.encontrarLivrosPorAutor(pesquisa);
        DoubleSummaryStatistics media = livros.stream()
                .mapToDouble(Livro::getQuantidadeDeDownloads)
                .summaryStatistics();
        return media.getAverage();
    }
}
