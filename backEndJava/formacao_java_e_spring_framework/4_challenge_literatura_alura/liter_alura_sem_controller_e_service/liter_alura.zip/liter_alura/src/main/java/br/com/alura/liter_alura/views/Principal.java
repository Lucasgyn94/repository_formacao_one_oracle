package br.com.alura.liter_alura.views;

import br.com.alura.liter_alura.dto.AutorDto;
import br.com.alura.liter_alura.dto.LivroDto;
import br.com.alura.liter_alura.models.Autor;
import br.com.alura.liter_alura.models.Livro;
import br.com.alura.liter_alura.repository.AutorRepository;
import br.com.alura.liter_alura.repository.LivroRepository;
import br.com.alura.liter_alura.service.ConsumoApi;
import br.com.alura.liter_alura.service.ConverteDados;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.DoubleSummaryStatistics;
import java.util.List;
import java.util.Scanner;

public class Principal {

    private Scanner sc = new Scanner(System.in);
    private ConsumoApi requisicao = new ConsumoApi();
    private AutorRepository repositorioAutor;
    private LivroRepository repositorioLivro;
    private List<Livro> books = new ArrayList<>();
    private ConverteDados conversor = new ConverteDados();
    private final String ADDRESS = "https://gutendex.com/books?search=";


    public Principal() {

    }
    public Principal(AutorRepository repositorioAutor, LivroRepository repositorioLivro) {
        this.repositorioAutor = repositorioAutor;
        this.repositorioLivro = repositorioLivro;
    }

    public void exibirMenu(){
        String menu = """
                **********************************************
                1 - Buscar livro pelo titulo
                2 - Listar livros registrados
                3 - Listar autores registrados
                4 - Listar autores vivos em determinado ano
                5 - Listar livros em determinado idioma
                6 - Top 10 livros
                7 - Buscar autores por nome
                8 - Media de downloads por autor
                
                0 - Sair
                **********************************************
                """;
        var opcao = -1;
        while (opcao != 0){
            System.out.println(menu);
            opcao = sc.nextInt();
            sc.nextLine();

            switch (opcao){
                case 1:
                    buscarNovoLivro();
                    break;
                case 2:
                    buscarLivrosRegistrados();
                    break;
                case 3:
                    buscarAutoresRegistrados();
                    break;
                case 4:
                    buscarAutoresVivosPorAno();
                    break;
                case 5:
                    buscarLivrosPorIdioma();
                    break;
                case 6:
                    buscarTop10();
                    break;
                case 7:
                    buscarAutorPorNome();
                    break;
                case 8:
                    mediaDeDownlaodsPorAutor();
                    break;
                case 0:
                    System.out.println("Saindo...");
                    break;
                default:
                    System.out.println("\n\n***Opção Inválida***\n\n");
            }
        }


    }

    private void buscarNovoLivro() {
        System.out.println("\nQual livro deseja buscar?");
        var buscaDoUsuario = sc.nextLine();
        var dados = requisicao.consumo(ADDRESS + buscaDoUsuario.replace(" ", "%20"));
        salvarNoDb(dados);
    }

    private void salvarNoDb(String dados){
        try{
            Livro livro = new Livro(conversor.obterDados(dados, LivroDto.class));
            Autor autor = new Autor(conversor.obterDados(dados, AutorDto.class));
            Autor autorDb = null;
            Livro bookDb = null;

            if (!repositorioAutor.existsByNome(autor.getNome())){
                repositorioAutor.save(autor);
                autorDb = autor;
            }else{
                autorDb = repositorioAutor.findByNome(autor.getNome());
            }
            if (!repositorioLivro.existsByNome(livro.getNome())){
                livro.setAutor(autorDb);
                repositorioLivro.save(livro);
                bookDb = livro;
            }else{
                bookDb = repositorioLivro.findByNome(livro.getNome());
            }
            System.out.println(bookDb);
        }catch (NullPointerException e){
            System.out.println("\n\n*** Livro não encontrado ***\n\n");
        }

    }


    private void buscarLivrosRegistrados() {
        var bucasDB = repositorioLivro.findAll();
        if(!bucasDB.isEmpty()){
            System.out.println("\nLivros cadastrados no banco de dados: ");
            bucasDB.forEach(System.out::println);
        }else{
            System.out.println("\nNenhum livro encontrado no banco de dados!");
        }
    }

    private void buscarAutoresRegistrados() {
        var buscaDb = repositorioAutor.findAll();
        if(!buscaDb.isEmpty()){
            System.out.println("\nAutores cadastrados no banco de dados:");
            buscaDb.forEach(System.out::println);
        }else{
            System.out.println("\nNenhum autor encontrado no banco de dados!");
        }
    }


    private void buscarAutoresVivosPorAno() {
        System.out.println("\nQual ano deseja pesquisar?");
        var anoSelecionado = sc.nextInt();
        sc.nextLine();
        var buscaAutoresNoDb = repositorioAutor.buscarPorAnoDeFalecimento(LocalDate.ofEpochDay(anoSelecionado));
        if(!buscaAutoresNoDb.isEmpty()){
            System.out.println("\n\nAtores vivos no ano de: " + anoSelecionado);
            buscaAutoresNoDb.forEach(System.out::println);
        }else {
            System.out.println("\nNenhum autor encontrado para esta data!");
        }
    }

    private void buscarLivrosPorIdioma() {
        var idiomasCadastrados = repositorioLivro.bucasidiomas();
        System.out.println("\nIdiomas cadastrados no banco:");
        idiomasCadastrados.forEach(System.out::println);
        System.out.println("\nSelecione um dos idiomas cadastrados no banco:\n");
        var idiomaSelecionado = sc.nextLine();
        repositorioLivro.buscarPorIdioma(idiomaSelecionado).forEach(System.out::println);
    }

    private void buscarTop10() {
        var top10 = repositorioLivro.findTop10ByOrderByQuantidadeDeDownloadsDesc();
        top10.forEach(System.out::println);
    }

    private void buscarAutorPorNome() {
        System.out.println("Qual o nome do autor?");
        var pesquisa = sc.nextLine();
        var autor = repositorioAutor.encontrarPorNome(pesquisa);
        if (!autor.isEmpty()){
            autor.forEach(System.out::println);
        }else{
            System.out.println("*** Autor não encontrado! ***");
        }
    }

    private void mediaDeDownlaodsPorAutor() {
        System.out.println("Qual autor deseja buscar?");
        var pesquisa = sc.nextLine();
        var test = repositorioLivro.encontrarLivrosPorAutor(pesquisa);
        DoubleSummaryStatistics media = test.stream()
                .mapToDouble(Livro::getQuantidadeDeDownloads)
                .summaryStatistics();
        System.out.println("Média de Downloads: "+ media.getAverage());
    }


}