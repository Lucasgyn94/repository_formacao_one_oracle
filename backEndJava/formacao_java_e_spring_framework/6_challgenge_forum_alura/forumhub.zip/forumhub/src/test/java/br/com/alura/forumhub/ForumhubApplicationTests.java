package br.com.alura.forumhub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ForumhubApplicationTests {

	@Test
	void contextLoads() {
	}

}
